package com.vn.dating_sim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatingSimApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatingSimApplication.class, args);
	}

}
